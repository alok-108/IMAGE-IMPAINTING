from typing import List
import cv2
import numpy as np


def boxes_from_mask(mask: np.ndarray) -> List[np.ndarray]:
    """
    Args:
        mask: (h, w, 1)  0~255

    Returns:

    """
    height, width = mask.shape[:2]
    _, thresh = cv2.threshold(mask, 127, 255, 0)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    boxes = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        box = np.array([x, y, x + w, y + h]).astype(int)

        box[::2] = np.clip(box[::2], 0, width)
        box[1::2] = np.clip(box[1::2], 0, height)
        boxes.append(box)

    return boxes


def resize_max_size(
        np_img, size_limit: int, interpolation=cv2.INTER_CUBIC
) -> np.ndarray:
    # Resize image's longer size to size_limit if longer size larger than size_limit
    h, w = np_img.shape[:2]
    if max(h, w) > size_limit:
        ratio = size_limit / max(h, w)
        new_w = int(w * ratio + 0.5)
        new_h = int(h * ratio + 0.5)
        return cv2.resize(np_img, dsize=(new_w, new_h), interpolation=interpolation)
    else:
        return np_img


def ceil_modulo(x, mod):
    if x % mod == 0:
        return x
    return (x // mod + 1) * mod


def pad_img_to_modulo(
        img: np.ndarray, mod: int, square: bool = False, min_size=None
):
    """

    Args:
        img: [H, W, C]
        mod:
        square: 是否为正方形
        min_size:

    Returns:

    """
    if len(img.shape) == 2:
        img = img[:, :, np.newaxis]
    height, width = img.shape[:2]
    out_height = ceil_modulo(height, mod)
    out_width = ceil_modulo(width, mod)

    if min_size is not None:
        assert min_size % mod == 0
        out_width = max(min_size, out_width)
        out_height = max(min_size, out_height)

    if square:
        max_size = max(out_height, out_width)
        out_height = max_size
        out_width = max_size

    return np.pad(
        img,
        ((0, out_height - height), (0, out_width - width), (0, 0)),
        mode="symmetric",
    )


def norm_img(np_img):
    if len(np_img.shape) == 2:
        np_img = np_img[:, :, np.newaxis]
    np_img = np.transpose(np_img, (2, 0, 1))
    np_img = np_img.astype("float32") / 255
    return np_img


def pad_batch_img_to_modulo(imgs, mod, square: bool = False, min_size=None):
    if len(imgs[0].shape) == 2:
        imgs = [img[:, :, np.newaxis] for img in imgs]
    max_height = max([img.shape[0] for img in imgs])
    max_width = max([img.shape[1] for img in imgs])

    out_height = ceil_modulo(max_height, mod)
    out_width = ceil_modulo(max_width, mod)

    if min_size is not None:
        assert min_size % mod == 0
        out_width = max(min_size, out_width)
        out_height = max(min_size, out_height)

    if square:
        max_size = max(out_height, out_width)
        out_height = max_size
        out_width = max_size

    imgs = [
        np.pad(img, ((0, out_height - img.shape[0]), (0, out_width - img.shape[1]), (0, 0)),
               mode="symmetric")
        for img in imgs
    ]

    return np.array(imgs)


def norm_batch_img(batch_img: np.ndarray):
    if len(batch_img.shape) == 3:
        batch_img = batch_img[:, :, :, np.newaxis]

    batch_img = np.transpose(batch_img, (0, 3, 1, 2))
    batch_img = batch_img.astype('float32') / 255
    return batch_img


def resize_batch_img(imgs, size_limit, interpolation=cv2.INTER_CUBIC):
    heights = [img.shape[0] for img in imgs]
    widths = [img.shape[1] for img in imgs]

    out_max_size = max ( max(heights),max(widths))
    if out_max_size > size_limit:
        out_max_size = size_limit

    batch_image = []
    for i in range(len(imgs)):
        ratio = out_max_size / max(heights[i],widths[i])
        new_width = int(widths[i]*ratio+0.5)
        new_height = int(heights[i]*ratio +0.5)
        batch_image.append(cv2.resize(imgs[i],dsize=(new_width,new_height),interpolation=interpolation))

    return batch_image
